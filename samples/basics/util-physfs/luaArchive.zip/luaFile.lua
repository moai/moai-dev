----------------------------------------------------------------
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
----------------------------------------------------------------

luaBlock = {}
print ("this file has been run")
luaBlock.helloString = "hello, this is from a file included with 'rquire' contained in an archive"
return luaBlock